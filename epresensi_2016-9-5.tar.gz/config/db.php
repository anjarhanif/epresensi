<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=adms_db',
    'username' => 'root',
    'password' => '123456',
    'charset' => 'utf8',
];
