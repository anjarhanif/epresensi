-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.0.45-community-nt - MySQL Community Edition (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for adms_db
CREATE DATABASE IF NOT EXISTS `adms_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `adms_db`;


-- Dumping structure for table adms_db.auth_group
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_group: 0 rows
DELETE FROM `auth_group`;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;


-- Dumping structure for table adms_db.auth_group_permissions
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id` (`group_id`),
  KEY `auth_group_permissions_permission_id` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_group_permissions: 0 rows
DELETE FROM `auth_group_permissions`;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;


-- Dumping structure for table adms_db.auth_message
CREATE TABLE IF NOT EXISTS `auth_message` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `auth_message_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_message: 0 rows
DELETE FROM `auth_message`;
/*!40000 ALTER TABLE `auth_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_message` ENABLE KEYS */;


-- Dumping structure for table adms_db.auth_permission
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_permission: 102 rows
DELETE FROM `auth_permission`;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
	(1, 'Can add session', 1, 'add_session'),
	(2, 'Can change session', 1, 'change_session'),
	(3, 'Can delete session', 1, 'delete_session'),
	(4, 'Can add permission', 2, 'add_permission'),
	(5, 'Can change permission', 2, 'change_permission'),
	(6, 'Can delete permission', 2, 'delete_permission'),
	(7, 'Can add group', 3, 'add_group'),
	(8, 'Can change group', 3, 'change_group'),
	(9, 'Can delete group', 3, 'delete_group'),
	(10, 'Can add user', 4, 'add_user'),
	(11, 'Can change user', 4, 'change_user'),
	(12, 'Can delete user', 4, 'delete_user'),
	(13, 'Can add message', 5, 'add_message'),
	(14, 'Can change message', 5, 'change_message'),
	(15, 'Can delete message', 5, 'delete_message'),
	(16, 'Can add content type', 6, 'add_contenttype'),
	(17, 'Can change content type', 6, 'change_contenttype'),
	(18, 'Can delete content type', 6, 'delete_contenttype'),
	(19, 'Can add log entry', 7, 'add_logentry'),
	(20, 'Can change log entry', 7, 'change_logentry'),
	(21, 'Can delete log entry', 7, 'delete_logentry'),
	(22, 'Can add department', 8, 'add_department'),
	(23, 'Can change department', 8, 'change_department'),
	(24, 'Can delete department', 8, 'delete_department'),
	(25, 'Can add device', 9, 'add_iclock'),
	(26, 'Can change device', 9, 'change_iclock'),
	(27, 'Can delete device', 9, 'delete_iclock'),
	(28, 'Pause device', 9, 'pause_iclock'),
	(29, 'Resume a resumed device', 9, 'resume_iclock'),
	(30, 'Upgrade firmware', 9, 'upgradefw_iclock'),
	(31, 'Copy data between device', 9, 'copyudata_iclock'),
	(32, 'Upload data again', 9, 'reloaddata_iclock'),
	(33, 'Upload transactions again', 9, 'reloadlogdata_iclock'),
	(34, 'Refresh device information', 9, 'info_iclock'),
	(35, 'Reboot device', 9, 'reboot_iclock'),
	(36, 'Upload new data', 9, 'loaddata_iclock'),
	(37, 'Clear data in device', 9, 'cleardata_iclock'),
	(38, 'Clear transactions in device', 9, 'clearlog_iclock'),
	(39, 'Set options of device', 9, 'devoption_iclock'),
	(40, 'Reset Password in device', 9, 'resetPwd_iclock'),
	(41, 'Restore employee to device', 9, 'restoreData_iclock'),
	(42, 'Output unlock signal', 9, 'unlock_iclock'),
	(43, 'Terminate alarm signal', 9, 'unalarm_iclock'),
	(44, 'Clear all employee', 9, 'clear_all_employee'),
	(45, 'Upgrade by u-pack', 9, 'upgrade_by_u-pack'),
	(46, 'Can add admin granted department', 10, 'add_deptadmin'),
	(47, 'Can change admin granted department', 10, 'change_deptadmin'),
	(48, 'Can delete admin granted department', 10, 'delete_deptadmin'),
	(49, 'Can add employee', 11, 'add_employee'),
	(50, 'Can change employee', 11, 'change_employee'),
	(51, 'Can delete employee', 11, 'delete_employee'),
	(52, 'Transfer employee to the device', 11, 'toDev_employee'),
	(53, 'Transfer to the device templately', 11, 'toDevWithin_employee'),
	(54, 'Delete employee from the device', 11, 'delDev_employee'),
	(55, 'Employee leave', 11, 'empLeave_employee'),
	(56, 'Move employee to a new device', 11, 'mvToDev_employee'),
	(57, 'Change employee\'s department', 11, 'toDepart_employee'),
	(58, 'Enroll employee\'s fingerprint', 11, 'enroll_employee'),
	(59, 'DataBase', 11, 'optionsDatabase_employee'),
	(60, 'Can add fingerprint', 12, 'add_fptemp'),
	(61, 'Can change fingerprint', 12, 'change_fptemp'),
	(62, 'Can delete fingerprint', 12, 'delete_fptemp'),
	(63, 'Can add transaction', 13, 'add_transaction'),
	(64, 'Can change transaction', 13, 'change_transaction'),
	(65, 'Can delete transaction', 13, 'delete_transaction'),
	(66, 'Clear Obsolete Data', 13, 'clearObsoleteData_transaction'),
	(67, 'Can add device operation log', 14, 'add_oplog'),
	(68, 'Can change device operation log', 14, 'change_oplog'),
	(69, 'Can delete device operation log', 14, 'delete_oplog'),
	(70, 'Transaction Monitor', 14, 'monitor_oplog'),
	(71, 'Can add data from device', 15, 'add_devlog'),
	(72, 'Can change data from device', 15, 'change_devlog'),
	(73, 'Can delete data from device', 15, 'delete_devlog'),
	(74, 'Can add command to device', 16, 'add_devcmds'),
	(75, 'Can change command to device', 16, 'change_devcmds'),
	(76, 'Can delete command to device', 16, 'delete_devcmds'),
	(77, 'Can add public information', 17, 'add_messages'),
	(78, 'Can change public information', 17, 'change_messages'),
	(79, 'Can delete public information', 17, 'delete_messages'),
	(80, 'Can add information subscription', 18, 'add_iclockmsg'),
	(81, 'Can change information subscription', 18, 'change_iclockmsg'),
	(82, 'Can delete information subscription', 18, 'delete_iclockmsg'),
	(83, 'Can add administration log', 19, 'add_adminlog'),
	(84, 'Can change administration log', 19, 'change_adminlog'),
	(85, 'Can delete administration log', 19, 'delete_adminlog'),
	(86, 'Can browse ContentType', 6, 'browse_contenttype'),
	(87, 'Can browse DeptAdmin', 10, 'browse_deptadmin'),
	(88, 'Can browse Group', 3, 'browse_group'),
	(89, 'Can browse IclockMsg', 18, 'browse_iclockmsg'),
	(90, 'Can browse Permission', 2, 'browse_permission'),
	(91, 'Can browse User', 4, 'browse_user'),
	(92, 'Can browse adminLog', 19, 'browse_adminlog'),
	(93, 'Can browse department', 8, 'browse_department'),
	(94, 'Can browse devcmds', 16, 'browse_devcmds'),
	(95, 'Can browse devlog', 15, 'browse_devlog'),
	(96, 'Can browse employee', 11, 'browse_employee'),
	(97, 'Can browse fptemp', 12, 'browse_fptemp'),
	(98, 'Can browse iclock', 9, 'browse_iclock'),
	(99, 'Can browse messages', 17, 'browse_messages'),
	(100, 'Can browse oplog', 14, 'browse_oplog'),
	(101, 'Can browse transaction', 13, 'browse_transaction'),
	(102, 'Init database', 13, 'init_database');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;


-- Dumping structure for table adms_db.auth_user
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_user: 1 rows
DELETE FROM `auth_user`;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `is_staff`, `is_active`, `is_superuser`, `last_login`, `date_joined`) VALUES
	(1, 'admin', '', '', 'fae_service@zkteco.com', 'sha1$7e2eb$903d62792a5aee00a01ef3c5565a0629cc56835d', 1, 1, 1, '2016-06-30 08:32:52', '2013-07-30 15:37:18');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;


-- Dumping structure for table adms_db.auth_user_groups
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id` (`user_id`),
  KEY `auth_user_groups_group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_user_groups: 0 rows
DELETE FROM `auth_user_groups`;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;


-- Dumping structure for table adms_db.auth_user_user_permissions
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id` (`user_id`),
  KEY `auth_user_user_permissions_permission_id` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.auth_user_user_permissions: 0 rows
DELETE FROM `auth_user_user_permissions`;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;


-- Dumping structure for table adms_db.checkinout
CREATE TABLE IF NOT EXISTS `checkinout` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL,
  `checktime` datetime NOT NULL,
  `checktype` varchar(1) NOT NULL,
  `verifycode` int(11) NOT NULL,
  `SN` varchar(20) default NULL,
  `sensorid` varchar(5) default NULL,
  `WorkCode` varchar(20) default NULL,
  `Reserved` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userid` (`userid`,`checktime`),
  KEY `checkinout_userid` (`userid`),
  KEY `checkinout_SN` (`SN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.checkinout: 0 rows
DELETE FROM `checkinout`;
/*!40000 ALTER TABLE `checkinout` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkinout` ENABLE KEYS */;


-- Dumping structure for table adms_db.departments
CREATE TABLE IF NOT EXISTS `departments` (
  `DeptID` int(11) NOT NULL,
  `DeptName` varchar(20) NOT NULL,
  `supdeptid` int(11) default NULL,
  PRIMARY KEY  (`DeptID`),
  KEY `DEPTNAME` (`DeptName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.departments: 1 rows
DELETE FROM `departments`;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`DeptID`, `DeptName`, `supdeptid`) VALUES
	(1, 'Our Company', 0);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;


-- Dumping structure for table adms_db.devcmds
CREATE TABLE IF NOT EXISTS `devcmds` (
  `id` int(11) NOT NULL auto_increment,
  `SN_id` varchar(20) NOT NULL,
  `CmdContent` longtext NOT NULL,
  `CmdCommitTime` datetime NOT NULL,
  `CmdTransTime` datetime default NULL,
  `CmdOverTime` datetime default NULL,
  `CmdReturn` int(11) default NULL,
  `User_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `devcmds_SN_id` (`SN_id`),
  KEY `devcmds_User_id` (`User_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.devcmds: 0 rows
DELETE FROM `devcmds`;
/*!40000 ALTER TABLE `devcmds` DISABLE KEYS */;
/*!40000 ALTER TABLE `devcmds` ENABLE KEYS */;


-- Dumping structure for table adms_db.devlog
CREATE TABLE IF NOT EXISTS `devlog` (
  `id` int(11) NOT NULL auto_increment,
  `SN_id` varchar(20) NOT NULL,
  `OP` varchar(8) NOT NULL,
  `Object` varchar(20) default NULL,
  `Cnt` int(11) NOT NULL,
  `ECnt` int(11) NOT NULL,
  `OpTime` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `devlog_SN_id` (`SN_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.devlog: 0 rows
DELETE FROM `devlog`;
/*!40000 ALTER TABLE `devlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `devlog` ENABLE KEYS */;


-- Dumping structure for table adms_db.django_admin_log
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL auto_increment,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) default NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `django_admin_log_user_id` (`user_id`),
  KEY `django_admin_log_content_type_id` (`content_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.django_admin_log: 0 rows
DELETE FROM `django_admin_log`;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;


-- Dumping structure for table adms_db.django_content_type
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.django_content_type: 19 rows
DELETE FROM `django_content_type`;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`, `name`, `app_label`, `model`) VALUES
	(1, 'session', 'sessions', 'session'),
	(2, 'permission', 'auth', 'permission'),
	(3, 'group', 'auth', 'group'),
	(4, 'user', 'auth', 'user'),
	(5, 'message', 'auth', 'message'),
	(6, 'content type', 'contenttypes', 'contenttype'),
	(7, 'log entry', 'admin', 'logentry'),
	(8, 'department', 'iclock', 'department'),
	(9, 'device', 'iclock', 'iclock'),
	(10, 'admin granted department', 'iclock', 'deptadmin'),
	(11, 'employee', 'iclock', 'employee'),
	(12, 'fingerprint', 'iclock', 'fptemp'),
	(13, 'transaction', 'iclock', 'transaction'),
	(14, 'device operation log', 'iclock', 'oplog'),
	(15, 'data from device', 'iclock', 'devlog'),
	(16, 'command to device', 'iclock', 'devcmds'),
	(17, 'public information', 'iclock', 'messages'),
	(18, 'information subscription', 'iclock', 'iclockmsg'),
	(19, 'administration log', 'iclock', 'adminlog');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;


-- Dumping structure for table adms_db.django_session
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY  (`session_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.django_session: 0 rows
DELETE FROM `django_session`;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;


-- Dumping structure for table adms_db.iclock
CREATE TABLE IF NOT EXISTS `iclock` (
  `SN` varchar(20) NOT NULL,
  `State` int(11) NOT NULL,
  `LastActivity` datetime default NULL,
  `TransTimes` varchar(50) default NULL,
  `TransInterval` int(11) NOT NULL,
  `LogStamp` varchar(20) default NULL,
  `OpLogStamp` varchar(20) default NULL,
  `PhotoStamp` varchar(20) default NULL,
  `Alias` varchar(20) NOT NULL,
  `DeptID` int(11) default NULL,
  `UpdateDB` varchar(10) NOT NULL,
  `Style` varchar(20) default NULL,
  `FWVersion` varchar(30) default NULL,
  `FPCount` int(11) default NULL,
  `TransactionCount` int(11) default NULL,
  `UserCount` int(11) default NULL,
  `MainTime` varchar(20) default NULL,
  `MaxFingerCount` int(11) default NULL,
  `MaxAttLogCount` int(11) default NULL,
  `DeviceName` varchar(30) default NULL,
  `AlgVer` varchar(30) default NULL,
  `FlashSize` varchar(10) default NULL,
  `FreeFlashSize` varchar(10) default NULL,
  `Language` varchar(30) default NULL,
  `VOLUME` varchar(10) default NULL,
  `DtFmt` varchar(10) default NULL,
  `IPAddress` varchar(20) default NULL,
  `IsTFT` varchar(5) default NULL,
  `Platform` varchar(20) default NULL,
  `Brightness` varchar(5) default NULL,
  `BackupDev` varchar(30) default NULL,
  `OEMVendor` varchar(30) default NULL,
  `City` varchar(50) default NULL,
  `AccFun` smallint(6) NOT NULL,
  `TZAdj` smallint(6) NOT NULL,
  `DelTag` smallint(6) NOT NULL,
  `FPVersion` varchar(10) default NULL,
  `PushVersion` varchar(10) default NULL,
  PRIMARY KEY  (`SN`),
  KEY `iclock_DeptID` (`DeptID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.iclock: 0 rows
DELETE FROM `iclock`;
/*!40000 ALTER TABLE `iclock` DISABLE KEYS */;
/*!40000 ALTER TABLE `iclock` ENABLE KEYS */;


-- Dumping structure for table adms_db.iclock_adminlog
CREATE TABLE IF NOT EXISTS `iclock_adminlog` (
  `id` int(11) NOT NULL auto_increment,
  `time` datetime NOT NULL,
  `User_id` int(11) default NULL,
  `model` varchar(40) default NULL,
  `action` varchar(40) NOT NULL,
  `object` varchar(40) default NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `iclock_adminlog_User_id` (`User_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.iclock_adminlog: 1 rows
DELETE FROM `iclock_adminlog`;
/*!40000 ALTER TABLE `iclock_adminlog` DISABLE KEYS */;
INSERT INTO `iclock_adminlog` (`id`, `time`, `User_id`, `model`, `action`, `object`, `count`) VALUES
	(1, '2016-06-30 08:32:52', 1, 'None', 'LOGIN', '127.0.0.1', 1);
/*!40000 ALTER TABLE `iclock_adminlog` ENABLE KEYS */;


-- Dumping structure for table adms_db.iclock_deptadmin
CREATE TABLE IF NOT EXISTS `iclock_deptadmin` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `iclock_deptadmin_user_id` (`user_id`),
  KEY `iclock_deptadmin_dept_id` (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.iclock_deptadmin: 0 rows
DELETE FROM `iclock_deptadmin`;
/*!40000 ALTER TABLE `iclock_deptadmin` DISABLE KEYS */;
/*!40000 ALTER TABLE `iclock_deptadmin` ENABLE KEYS */;


-- Dumping structure for table adms_db.iclock_iclockmsg
CREATE TABLE IF NOT EXISTS `iclock_iclockmsg` (
  `id` int(11) NOT NULL auto_increment,
  `SN_id` varchar(20) NOT NULL,
  `MsgType` int(11) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime default NULL,
  `MsgParam` varchar(32) default NULL,
  `MsgContent` varchar(200) default NULL,
  `LastTime` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `iclock_iclockmsg_SN_id` (`SN_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.iclock_iclockmsg: 0 rows
DELETE FROM `iclock_iclockmsg`;
/*!40000 ALTER TABLE `iclock_iclockmsg` DISABLE KEYS */;
/*!40000 ALTER TABLE `iclock_iclockmsg` ENABLE KEYS */;


-- Dumping structure for table adms_db.iclock_messages
CREATE TABLE IF NOT EXISTS `iclock_messages` (
  `id` int(11) NOT NULL auto_increment,
  `MsgType` int(11) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime default NULL,
  `MsgContent` longtext,
  `MsgImage` varchar(64) default NULL,
  `DeptID_id` int(11) default NULL,
  `MsgParam` varchar(32) default NULL,
  PRIMARY KEY  (`id`),
  KEY `iclock_messages_DeptID_id` (`DeptID_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.iclock_messages: 0 rows
DELETE FROM `iclock_messages`;
/*!40000 ALTER TABLE `iclock_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `iclock_messages` ENABLE KEYS */;


-- Dumping structure for table adms_db.iclock_oplog
CREATE TABLE IF NOT EXISTS `iclock_oplog` (
  `id` int(11) NOT NULL auto_increment,
  `SN` varchar(20) default NULL,
  `admin` int(11) NOT NULL,
  `OP` smallint(6) NOT NULL,
  `OPTime` datetime NOT NULL,
  `Object` int(11) default NULL,
  `Param1` int(11) default NULL,
  `Param2` int(11) default NULL,
  `Param3` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `SN` (`SN`,`OPTime`),
  KEY `iclock_oplog_SN` (`SN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.iclock_oplog: 0 rows
DELETE FROM `iclock_oplog`;
/*!40000 ALTER TABLE `iclock_oplog` DISABLE KEYS */;
/*!40000 ALTER TABLE `iclock_oplog` ENABLE KEYS */;


-- Dumping structure for table adms_db.template
CREATE TABLE IF NOT EXISTS `template` (
  `templateid` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL,
  `Template` longtext NOT NULL,
  `FingerID` smallint(6) NOT NULL,
  `Valid` smallint(6) NOT NULL,
  `DelTag` smallint(6) NOT NULL,
  `SN` varchar(20) default NULL,
  `UTime` datetime default NULL,
  `BITMAPPICTURE` longtext,
  `BITMAPPICTURE2` longtext,
  `BITMAPPICTURE3` longtext,
  `BITMAPPICTURE4` longtext,
  `USETYPE` smallint(6) default NULL,
  `Template2` longtext,
  `Template3` longtext,
  PRIMARY KEY  (`templateid`),
  UNIQUE KEY `userid` (`userid`,`FingerID`),
  UNIQUE KEY `USERFINGER` (`userid`,`FingerID`),
  KEY `template_userid` (`userid`),
  KEY `template_SN` (`SN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.template: 0 rows
DELETE FROM `template`;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;


-- Dumping structure for table adms_db.userinfo
CREATE TABLE IF NOT EXISTS `userinfo` (
  `userid` int(11) NOT NULL auto_increment,
  `badgenumber` varchar(20) NOT NULL,
  `defaultdeptid` int(11) default NULL,
  `name` varchar(40) default NULL,
  `Password` varchar(20) default NULL,
  `Card` varchar(20) default NULL,
  `Privilege` int(11) default NULL,
  `AccGroup` int(11) default NULL,
  `TimeZones` varchar(20) default NULL,
  `Gender` varchar(2) default NULL,
  `Birthday` datetime default NULL,
  `street` varchar(40) default NULL,
  `zip` varchar(6) default NULL,
  `ophone` varchar(20) default NULL,
  `FPHONE` varchar(20) default NULL,
  `pager` varchar(20) default NULL,
  `minzu` varchar(8) default NULL,
  `title` varchar(20) default NULL,
  `SN` varchar(20) default NULL,
  `SSN` varchar(20) default NULL,
  `UTime` datetime default NULL,
  `State` varchar(2) default NULL,
  `City` varchar(2) default NULL,
  `SECURITYFLAGS` smallint(6) default NULL,
  `DelTag` smallint(6) NOT NULL,
  `RegisterOT` int(11) default NULL,
  `AutoSchPlan` int(11) default NULL,
  `MinAutoSchInterval` int(11) default NULL,
  `Image_id` int(11) default NULL,
  PRIMARY KEY  (`userid`),
  KEY `userinfo_defaultdeptid` (`defaultdeptid`),
  KEY `userinfo_SN` (`SN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table adms_db.userinfo: 0 rows
DELETE FROM `userinfo`;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
