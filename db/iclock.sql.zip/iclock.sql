-- phpMyAdmin SQL Dump
-- version 4.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2016 at 01:57 PM
-- Server version: 5.5.40
-- PHP Version: 5.4.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `adms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `iclock`
--

CREATE TABLE IF NOT EXISTS `iclock` (
  `SN` varchar(20) NOT NULL,
  `State` int(11) NOT NULL,
  `LastActivity` datetime DEFAULT NULL,
  `TransTimes` varchar(50) DEFAULT NULL,
  `TransInterval` int(11) NOT NULL,
  `LogStamp` varchar(20) DEFAULT NULL,
  `OpLogStamp` varchar(20) DEFAULT NULL,
  `PhotoStamp` varchar(20) DEFAULT NULL,
  `Alias` varchar(20) NOT NULL,
  `DeptID` int(11) DEFAULT NULL,
  `UpdateDB` varchar(10) NOT NULL,
  `Style` varchar(20) DEFAULT NULL,
  `FWVersion` varchar(30) DEFAULT NULL,
  `FPCount` int(11) DEFAULT NULL,
  `TransactionCount` int(11) DEFAULT NULL,
  `UserCount` int(11) DEFAULT NULL,
  `MainTime` varchar(20) DEFAULT NULL,
  `MaxFingerCount` int(11) DEFAULT NULL,
  `MaxAttLogCount` int(11) DEFAULT NULL,
  `DeviceName` varchar(30) DEFAULT NULL,
  `AlgVer` varchar(30) DEFAULT NULL,
  `FlashSize` varchar(10) DEFAULT NULL,
  `FreeFlashSize` varchar(10) DEFAULT NULL,
  `Language` varchar(30) DEFAULT NULL,
  `VOLUME` varchar(10) DEFAULT NULL,
  `DtFmt` varchar(10) DEFAULT NULL,
  `IPAddress` varchar(20) DEFAULT NULL,
  `IsTFT` varchar(5) DEFAULT NULL,
  `Platform` varchar(20) DEFAULT NULL,
  `Brightness` varchar(5) DEFAULT NULL,
  `BackupDev` varchar(30) DEFAULT NULL,
  `OEMVendor` varchar(30) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `AccFun` smallint(6) NOT NULL,
  `TZAdj` smallint(6) NOT NULL,
  `DelTag` smallint(6) NOT NULL,
  `FPVersion` varchar(10) DEFAULT NULL,
  `PushVersion` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iclock`
--

INSERT INTO `iclock` (`SN`, `State`, `LastActivity`, `TransTimes`, `TransInterval`, `LogStamp`, `OpLogStamp`, `PhotoStamp`, `Alias`, `DeptID`, `UpdateDB`, `Style`, `FWVersion`, `FPCount`, `TransactionCount`, `UserCount`, `MainTime`, `MaxFingerCount`, `MaxAttLogCount`, `DeviceName`, `AlgVer`, `FlashSize`, `FreeFlashSize`, `Language`, `VOLUME`, `DtFmt`, `IPAddress`, `IsTFT`, `Platform`, `Brightness`, `BackupDev`, `OEMVendor`, `City`, `AccFun`, `TZAdj`, `DelTag`, `FPVersion`, `PushVersion`) VALUES
('2367771160022', 1, '2016-07-19 14:57:00', '00:00;14:05', 1, '531908302', '531824321', '', 'Biro Umum', 2, '1111111100', 'F7', 'Ver 6.60 Mar 18 2011', 354, 1088, 174, '2011-03-18 07:22:56', 50000, 500000, 'MultimediaSerie', 'Finger VX', '230912', '208436', '69', '99', '6', '172.16.10.201', '1', 'ZEM600_TFT', NULL, '', 'Fingerspot', '', 15, 8, 0, '10', '0.0'),
('6571145200012', 1, '2016-07-19 14:57:31', '00:00;14:05', 1, '9999', '9999', '', 'Biro Adm. Kesra', 8, '1111111100', 'F7', 'Ver 1.0.0-20140512', 49, 6249, 45, '1970-01-01 00:00:00', NULL, NULL, 'Premier Series', NULL, '225280', '181800', NULL, '100', '0', '172.16.8.6', NULL, NULL, NULL, '', NULL, '', 0, 8, 0, '10', '0.0'),
('0571142500092', 1, '2016-07-19 14:57:28', '00:00;14:05', 1, '531932202', '531913760', '', 'Biro Organisasi', 3, '1111111100', 'F7', 'Ver 6.5.4(build 147-3684-03)', 83, 3, 85, '1970-01-01 00:00:11', 3000, 100000, 'Premier Series', 'Finger VX', '105472', '75688', '73', '67', '0', '172.16.8.2', '1', 'ZEM560_TFT', '80', '', 'Fingerspot', '', 0, 8, 0, '10', '0.0'),
('0571142500052', 1, '2016-07-19 14:57:20', '00:00;14:05', 1, '499657119', '531913982', '', 'Biro KSDA', 4, '1111111100', 'F7', 'Ver 6.5.4(build 147-3684-03)', 39, 9, 38, '1970-01-01 00:00:10', 3000, 100000, 'Premier Series', 'Finger VX', '105472', '75760', '73', '45', '0', '172.16.8.3', '1', 'ZEM560_TFT', '80', '', 'Fingerspot', '', 0, 8, 0, '10', '0.0'),
('0571142500028', 1, '2016-07-19 14:57:25', '00:00;14:05', 1, '531500766', '531914665', '', 'Biro Ekonomi', 9, '1111111100', 'F7', 'Ver 6.5.4(build 147-3684-03)', 50, 178, 50, '1970-01-01 00:00:11', 3000, 100000, 'Premier Series', 'Finger VX', '105472', '75600', '69', '45', '0', '172.16.8.4', '1', 'ZEM560_TFT', '80', '', 'Fingerspot', '', 0, 8, 0, '10', '0.0'),
('0571142500057', 1, '2016-07-19 14:57:26', '00:00;14:05', 1, '531930402', '531915233', '', 'Biro Hukum', 5, '1111111100', 'F7', 'Ver 6.5.4(build 147-3684-03)', 47, 7, 41, '1970-01-01 00:00:10', 3000, 100000, 'Premier Series', 'Finger VX', '105472', '75748', '73', '45', '0', '172.16.8.5', '1', 'ZEM560_TFT', '80', '', 'Fingerspot', '', 0, 8, 0, '10', '0.0'),
('0571142500056', 1, '2016-07-19 14:57:25', '00:00;14:05', 1, '531929186', '531921635', '', 'Biro Pemerintahan', 7, '1111111100', 'F7', 'Ver 6.5.4(build 147-3684-03)', 98, 17, 51, '1970-01-01 00:00:10', 3000, 100000, 'Premier Series', 'Finger VX', '105472', '75664', '73', '45', '7', '172.16.60.20', '1', 'ZEM560_TFT', '80', '', 'Fingerspot', '', 0, 8, 0, '10', '0.0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `iclock`
--
ALTER TABLE `iclock`
 ADD PRIMARY KEY (`SN`), ADD KEY `iclock_DeptID` (`DeptID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
