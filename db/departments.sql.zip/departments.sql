-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 13, 2016 at 08:14 AM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `adms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `DeptID` int(11) NOT NULL,
  `DeptName` varchar(20) NOT NULL,
  `supdeptid` int(11) DEFAULT NULL,
  PRIMARY KEY (`DeptID`),
  KEY `DEPTNAME` (`DeptName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DeptID`, `DeptName`, `supdeptid`) VALUES
(0, 'Pemprov NTB', 0),
(1, 'Biro Pemerintahan', 0),
(2, 'Biro Hukum', 0),
(3, 'Biro Organisasi', 0),
(4, 'Biro Ekonomi', 0),
(5, 'Biro AP & ULPBJ', 0),
(6, 'Biro Kerjasama SDA', 0),
(7, 'Biro Umum', 0),
(8, 'Biro Humas  Protokol', 0),
(9, 'Biro Kesra', 0),
(10, 'Dinas Budpar', 0),
(11, 'Dinas Kehutanan', 0),
(12, 'Dislutkan', 0),
(13, 'Dinas Kesehatan', 0),
(14, 'Diskop & UMKM', 0),
(15, 'Dinas PU', 0),
(16, 'Dispenda', 0),
(17, 'Dikpora', 0),
(18, 'Dishubkominfo', 0),
(19, 'Disperindag', 0),
(20, 'Dinas Perkebunan', 0),
(21, 'Distamben', 0),
(22, 'Dinas Pertanian', 0),
(23, 'Disnakeswan', 0),
(24, 'Disospencapil', 0),
(25, 'Disnakertrans', 0),
(26, 'BLHP', 0),
(27, 'Bakesbang Poldagri', 0),
(28, 'BKP', 0),
(29, 'BKPMPT', 0),
(30, 'Baperpus Arsip', 0),
(31, 'BPMPD', 0),
(32, 'BP3AKB', 0),
(33, 'BKD Diklat', 0),
(34, 'BAPPEDA', 0),
(35, 'Bakorluh', 0),
(36, 'BPBD', 0),
(37, 'Inspektorat', 0),
(38, 'Satpol PP', 0),
(39, 'Kantor Penghubung', 0),
(40, 'RSU', 0),
(41, 'RSJ', 0),
(42, 'Sekretariat Dewan', 0),
(43, 'Sekretariat Korpri', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
